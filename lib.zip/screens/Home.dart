import 'dart:convert';

import 'package:test_app/constraints.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:async';

class MyHomePage extends StatefulWidget {
  @override

  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  Completer<GoogleMapController> _controller = Completer();
  Set<Marker> _markers = Set();
  static final gwanghwamun = CameraPosition(
    target: LatLng(37.575929, 126.976849),
    zoom: 14.0,
  );

  void _searchPlaces(String locationName, double latitude, double longitude)async{
    setState(() {
      _markers.clear();
    });
    final String url = '$baseUrl?key=$API_KEY&location=$latitude,$longitude&radius=500&language=ko&keyword=$locationName';
    final response = await http.get(url);
    if(response.statusCode==200){
      final data = jsonDecode(response.body);

      if(data['status']=='OK'){
        GoogleMapController controller = await _controller.future;
        setState(() {
          final foundPlaces = data['results'];
          for(int i =0; i<foundPlaces.length;i++){
            _markers.add(
                Marker(
                    markerId: MarkerId(foundPlaces[i]['id']),
                    position: LatLng(
                      foundPlaces[i]['geometry']['location']['lat'],
                      foundPlaces[i]['geometry']['location']['lng'],
                    ),
                    infoWindow: InfoWindow(
                        title: foundPlaces[i]['name'],
                        snippet: foundPlaces[i]['vicinity']
                    )
                )
            );
          }
        });
      }
    }
    else{
      print('Fail');
    }
  }

  void _onMapCreated(GoogleMapController controller){
    _searchPlaces('주차장', 37.575929, 126.976849);
    _controller.complete(controller);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Center(
        child: GoogleMap(
        mapType: MapType.normal,
        initialCameraPosition: gwanghwamun,
        onMapCreated: _onMapCreated,
          markers: _markers,
          compassEnabled: true,
          zoomGesturesEnabled: true,
          rotateGesturesEnabled: true,
          scrollGesturesEnabled: true,
          tiltGesturesEnabled: true,
        ),
        ),
    );
  }

}