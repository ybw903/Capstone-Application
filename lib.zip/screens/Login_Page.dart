import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'Main_Screen.dart';
import 'Registration_Screen.dart';

class LoginPage extends StatefulWidget{
  @override
  State<StatefulWidget> createState(){
    return new _LoginPageState();
  }
}

class _LoginPageState extends State<LoginPage>{
  final formKey = new GlobalKey<FormState>();
  String _user_name;
  String _password;
  signIn(BuildContext context) async {
    var response = await http.post("http://10.0.2.2:5000/login",
        body: jsonEncode(
          {
            'username' : _user_name,
            'password' : _password
          }
        ),
      headers: {'Content-Type': "application/json"}
    );
    if(response.statusCode==200){
      print("ok");
      Navigator.push(context, MaterialPageRoute(builder: (context)=>MainScreen()));

    }
    else
      print(response.body);
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    // TODO: implement build
    return new Scaffold(
      body: new Stack(
        alignment: Alignment.center,
        children: <Widget>[
          new Container(color: Colors.white,),
          new Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[
              Image.asset(
                'assets/parking.jpg',
                height: size.height*0.35,
                width: size.width,
              ),
              Padding(
                  padding: EdgeInsets.all(size.width*0.05),
                  child:  new Card(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16)
                      ),
                      elevation: 6,
                      child: Padding(
                        padding: EdgeInsets.all(12.0),
                        child: Form(
                            key: formKey,
                            child: new Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: <Widget>[
                                new TextFormField(
                                  decoration: new InputDecoration(
                                      icon: Icon(Icons.account_circle),
                                      labelText: 'UserNmae'),
                                  validator: (val)=>
                                  val.isEmpty? 'UserName cannt\'t be empty':null,
                                  onSaved: (val)=> _user_name=val,
                                ),
                                new TextFormField(
                                  obscureText: true,
                                  decoration: new InputDecoration(
                                      icon: Icon(Icons.vpn_key),
                                      labelText: 'Password'),
                                  validator: (val)=>
                                  val.isEmpty? 'Password can\'t be empty':null,
                                  onSaved: (val)=>_password=val,
                                ),
                                new RaisedButton(
                                  color: Colors.blue,
                                    child: new Text(
                                      'Login',
                                      style: new TextStyle(fontSize: 20.0,color: Colors.white),

                                    ),
                                    onPressed : (){
                                      if(formKey.currentState.validate()){
                                        formKey.currentState.save();
                                        signIn(context);
                                      }
                                    }
                                ),
                                new RaisedButton(
                                    color: Colors.red,
                                    child: new Text(
                                      'Registration',
                                      style: new TextStyle(fontSize: 20.0, color: Colors.white),
                                    ),
                                    onPressed:()=> Navigator.push(context, MaterialPageRoute(builder: (context)=>RegistrationScreen()))
                                )
                              ],
                            )
                        ),
                      )
                  )
              ),
              new Container(height: size.height*0.1,)
            ],
          )

        ],
      )
    );
  }
}

