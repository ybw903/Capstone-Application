import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:test_app/screens/Home.dart';
import 'Home.dart';

class MainScreen extends StatefulWidget{
  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen>{
  PageController _pageController;
  int _page = 0;
  String _user_name="user_name";
  @override
  Widget build(BuildContext context){
    return Scaffold(
        appBar: AppBar(title: Text('title'),),
        drawer: Drawer(
          child: ListView(
            children: <Widget>[
              DrawerHeader(
                child: Card(
                  child: Row(
                    children: <Widget>[
                      Icon(Icons.account_circle),
                      Text(_user_name),
                    ],
                  ),
                ),
                decoration: BoxDecoration(
                  color: Colors.blue,
                ),
              ),
              ListTile(
                title: Text('주차권'),
              ),
              ListTile(
                title: Text('쿠폰함'),
              ),
              Divider(
                color: Colors.blue,
              ),
              ListTile(
                title: Text('공지사항'),
              ),
              ListTile(
                title: Text('계정관리'),
              ),
              ListTile(
                title: Text('환경설정'),
              ),
            ],
          ),
        ),
        body: PageView(
          controller: _pageController,
          children: <Widget>[
            MyHomePage()
          ],
        ),
      );
  }
}