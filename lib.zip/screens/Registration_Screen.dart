import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'Main_Screen.dart';

class RegistrationScreen extends StatefulWidget{
  @override
  State<StatefulWidget> createState(){
    return new _RegistrationScreenState();
  }
}

class _RegistrationScreenState extends State<RegistrationScreen>{
  final formKey = new GlobalKey<FormState>();
  String _user_name;
  String _password;
  signIn(BuildContext context) async {
    var response = await http.post("http://10.0.2.2:5000/login",
        body: jsonEncode(
            {
              'username' : _user_name,
              'password' : _password
            }
        ),
        headers: {'Content-Type': "application/json"}
    );
    if(response.statusCode==200){
      print("ok");
      Navigator.push(context, MaterialPageRoute(builder: (context)=>MainScreen()));

    }
    else
      print(response.body);
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Scaffold(
        appBar: null,
        body: new Container(
          padding: EdgeInsets.all(16),
          child: new Form(
              key: formKey,
              child: new Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  new TextFormField(
                    decoration: new InputDecoration(labelText: 'UserNmae'),
                    validator: (val)=>
                    val.isEmpty? 'UserName cannt\'t be empty':null,
                    onSaved: (val)=> _user_name=val,
                  ),
                  new TextFormField(
                    obscureText: true,
                    decoration: new InputDecoration(labelText: 'Password'),
                    validator: (val)=>
                    val.isEmpty? 'Password can\'t be empty':null,
                    onSaved: (val)=>_password=val,
                  ),

                  new Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      new RaisedButton(
                          child: new Text(
                            'Registration',
                            style: new TextStyle(fontSize: 20.0),
                          ),
                          onPressed : (){
                            if(formKey.currentState.validate()){
                              formKey.currentState.save();
                              signIn(context);
                            }
                          }
                      ),
                      new RaisedButton(
                          child: new Text(
                            'Back',
                            style: new TextStyle(fontSize: 20.0),
                          ),
                          onPressed: null
                      )
                    ],
                  ),

                ],
              )
          ),
        )
    );
  }
}

