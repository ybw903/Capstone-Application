class Auth{

}